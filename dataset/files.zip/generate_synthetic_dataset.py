"""
합성 임베딩 학습 데이터 생성 스크립트
- Anthropic Claude API를 사용하여 라벨당 고품질 합성 문장 생성
- 라벨별 definition + when + not_when을 컨텍스트로 제공
- 생성된 데이터는 embedding_synthetic_dataset.json으로 저장
"""

import json
import time
import os
import random
from pathlib import Path

# ─────────────────────────────────────────
# 설정
# ─────────────────────────────────────────
SAMPLES_PER_LABEL   = 100   # 라벨당 생성할 문장 수
BATCH_SIZE          = 20    # API 1회 호출당 요청 문장 수 (비용/속도 균형)
OUTPUT_PATH         = "embedding_synthetic_dataset_v2.json"
CHECKPOINT_PATH     = "generate_checkpoint.json"   # 중단 후 재시작용 체크포인트
MODEL               = "claude-sonnet-4-20250514"
MAX_TOKENS          = 4096
RETRY_LIMIT         = 3
RETRY_DELAY         = 5   # seconds

# ─────────────────────────────────────────
# 프롬프트 템플릿
# ─────────────────────────────────────────
SYSTEM_PROMPT = """당신은 한국어 리더십 텍스트 분석 시스템을 위한 학습 데이터를 생성하는 전문가입니다.
주어진 리더십 라벨에 해당하는 실제 업무 현장에서 일어날 법한 한국어 문장을 생성합니다.

규칙:
1. 각 문장은 실제 업무 현장에서 리더가 말하거나 행동하는 상황을 묘사합니다
2. 문장은 자연스러운 한국어로 작성합니다 (존댓말/반말 모두 가능)
3. 문장 길이는 20~120자 사이로 다양하게 작성합니다
4. ~, [내용], {내용} 같은 placeholder를 절대 사용하지 않습니다
5. 모든 문장은 구체적이고 완성된 표현이어야 합니다
6. 각 문장은 서로 다른 상황과 표현 방식을 사용합니다
7. 직접 발화 문장, 상황 묘사 문장, 회의록 형식 등 다양한 형식을 섞습니다
8. not_when 조건에 해당하는 문장은 절대 생성하지 않습니다

응답 형식: JSON 배열만 반환합니다. 다른 설명 없이 아래 형식만 반환합니다:
["문장1", "문장2", "문장3", ...]"""

USER_PROMPT_TEMPLATE = """다음 리더십 라벨에 해당하는 한국어 문장 {n}개를 생성하세요.

라벨 ID: {label_id}
라벨 이름: {label_name}
정의: {definition}
적용 상황 (이 라벨이 탐지되어야 하는 상황): {when}
제외 상황 (이 라벨이 탐지되면 안 되는 상황): {not_when}

위 정의와 적용 상황에 딱 맞는 문장 {n}개를 JSON 배열로 반환하세요."""


# ─────────────────────────────────────────
# API 호출 함수
# ─────────────────────────────────────────
def call_claude_api(label: dict, n: int) -> list[str]:
    """Claude API를 호출하여 라벨에 맞는 합성 문장 생성"""
    import urllib.request

    user_prompt = USER_PROMPT_TEMPLATE.format(
        label_id   = label["label_id"],
        label_name = label["label_name"],
        definition = label.get("definition", label["label_name"]),
        when       = label.get("when", "").split("|")[0].strip(),   # 예시 부분 제외, 키워드만
        not_when   = label.get("not_when", "없음"),
        n          = n
    )

    payload = json.dumps({
        "model": MODEL,
        "max_tokens": MAX_TOKENS,
        "system": SYSTEM_PROMPT,
        "messages": [{"role": "user", "content": user_prompt}]
    }).encode("utf-8")

    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data    = payload,
        headers = {
            "Content-Type":      "application/json",
            "anthropic-version": "2023-06-01",
        },
        method  = "POST"
    )

    for attempt in range(RETRY_LIMIT):
        try:
            with urllib.request.urlopen(req, timeout=60) as resp:
                result = json.loads(resp.read())
                raw_text = result["content"][0]["text"].strip()

                # JSON 파싱
                # 마크다운 코드블록 제거
                if raw_text.startswith("```"):
                    raw_text = raw_text.split("```")[1]
                    if raw_text.startswith("json"):
                        raw_text = raw_text[4:]
                raw_text = raw_text.strip()

                sentences = json.loads(raw_text)

                # 품질 필터링
                filtered = []
                for s in sentences:
                    s = s.strip()
                    # placeholder 제거
                    if any(p in s for p in ["~", "[내용]", "{내용}", "..."]):
                        continue
                    # 너무 짧거나 긴 문장 제거
                    if len(s) < 15 or len(s) > 200:
                        continue
                    # boilerplate 패턴 제거
                    bad_patterns = [
                        "라고 반복적으로 강조했습니다",
                        "이어서 팀원들의 반응을 보며 추가 지시를 내렸다",
                        "부탁드립니다 라고",
                        "라는 지시가 내려왔습니다",
                        "팀원들이 부담을 느꼈습니다",
                        "그대로 진행되었습니다",
                    ]
                    if any(bp in s for bp in bad_patterns):
                        continue
                    filtered.append(s)

                return filtered

        except Exception as e:
            print(f"    API 오류 (시도 {attempt+1}/{RETRY_LIMIT}): {e}")
            if attempt < RETRY_LIMIT - 1:
                time.sleep(RETRY_DELAY * (attempt + 1))

    return []


# ─────────────────────────────────────────
# 체크포인트 관리
# ─────────────────────────────────────────
def load_checkpoint() -> dict:
    if Path(CHECKPOINT_PATH).exists():
        with open(CHECKPOINT_PATH) as f:
            return json.load(f)
    return {}


def save_checkpoint(checkpoint: dict):
    with open(CHECKPOINT_PATH, "w", encoding="utf-8") as f:
        json.dump(checkpoint, f, ensure_ascii=False, indent=2)


# ─────────────────────────────────────────
# 메인 생성 루프
# ─────────────────────────────────────────
def generate_dataset():
    # 라벨 로드
    with open("positive_micro_labels_enhanced.json") as f:
        pos_labels = json.load(f)["micro_labels"]
    with open("negative_micro_labels_enhanced.json") as f:
        neg_labels = json.load(f)["micro_labels"]

    all_labels = pos_labels + neg_labels
    print(f"총 라벨 수: {len(all_labels)}개 (긍정 {len(pos_labels)} + 부정 {len(neg_labels)})")
    print(f"목표: 라벨당 {SAMPLES_PER_LABEL}개 × {len(all_labels)}개 = {SAMPLES_PER_LABEL * len(all_labels)}개\n")

    # 체크포인트 로드 (중단된 경우 이어서)
    checkpoint = load_checkpoint()
    results = checkpoint.get("results", [])
    done_labels = set(checkpoint.get("done_labels", []))

    print(f"체크포인트: {len(done_labels)}개 라벨 완료, 데이터 {len(results)}개 보유\n")

    total_labels = len(all_labels)

    for i, label in enumerate(all_labels):
        lid = label["label_id"]

        if lid in done_labels:
            print(f"[{i+1}/{total_labels}] {lid} - 스킵 (이미 완료)")
            continue

        print(f"[{i+1}/{total_labels}] {lid} ({label['label_name']}) 생성 중...", end="", flush=True)

        label_samples = []
        attempts = 0
        max_attempts = 8   # 100개 목표, 배치 20개 × 최대 8회

        while len(label_samples) < SAMPLES_PER_LABEL and attempts < max_attempts:
            needed = SAMPLES_PER_LABEL - len(label_samples)
            batch_n = min(BATCH_SIZE, needed + 5)   # 필터링 여유분 +5

            batch = call_claude_api(label, batch_n)

            # 중복 제거
            existing_texts = {s["text"] for s in label_samples}
            for text in batch:
                if text not in existing_texts:
                    label_samples.append({
                        "text":       text,
                        "label_id":   lid,
                        "label_name": label["label_name"],
                        "label_type": "positive" if lid.startswith("M") else "negative"
                    })
                    existing_texts.add(text)

            attempts += 1
            time.sleep(0.5)   # API rate limit 방지

        # 100개 초과 시 랜덤 샘플링
        if len(label_samples) > SAMPLES_PER_LABEL:
            label_samples = random.sample(label_samples, SAMPLES_PER_LABEL)

        results.extend(label_samples)
        done_labels.add(lid)

        print(f" → {len(label_samples)}개 생성 완료 (총 누계: {len(results)}개)")

        # 체크포인트 저장 (5개 라벨마다)
        if (i + 1) % 5 == 0:
            save_checkpoint({"results": results, "done_labels": list(done_labels)})
            print(f"  💾 체크포인트 저장 ({len(done_labels)}개 라벨 완료)")

    # 최종 저장
    random.shuffle(results)   # 라벨 순서 셔플
    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

    # 체크포인트 삭제
    if Path(CHECKPOINT_PATH).exists():
        os.remove(CHECKPOINT_PATH)

    # 결과 통계
    from collections import Counter
    label_counts = Counter(r["label_id"] for r in results)
    pos_count = sum(1 for r in results if r["label_type"] == "positive")
    neg_count = sum(1 for r in results if r["label_type"] == "negative")

    print(f"\n{'='*50}")
    print(f"생성 완료!")
    print(f"총 데이터: {len(results)}개")
    print(f"  긍정 라벨: {pos_count}개")
    print(f"  부정 라벨: {neg_count}개")
    print(f"라벨당 최소/최대: {min(label_counts.values())} / {max(label_counts.values())}개")
    under_80 = [lid for lid, cnt in label_counts.items() if cnt < 80]
    if under_80:
        print(f"80개 미만 라벨: {under_80}")
    print(f"저장 경로: {OUTPUT_PATH}")


# ─────────────────────────────────────────
# 단일 라벨 테스트 함수
# ─────────────────────────────────────────
def test_single_label(label_id: str = "N02-03"):
    """실행 전 특정 라벨로 품질 테스트"""
    with open("positive_micro_labels_enhanced.json") as f:
        pos = {l["label_id"]: l for l in json.load(f)["micro_labels"]}
    with open("negative_micro_labels_enhanced.json") as f:
        neg = {l["label_id"]: l for l in json.load(f)["micro_labels"]}

    all_labels = {**pos, **neg}
    label = all_labels.get(label_id)

    if not label:
        print(f"라벨 {label_id} 없음")
        return

    print(f"테스트 라벨: {label_id} ({label['label_name']})")
    print(f"definition: {label.get('definition', '없음')}")
    print(f"when: {label.get('when', '없음')[:100]}")
    print()

    samples = call_claude_api(label, 10)
    print(f"생성된 샘플 {len(samples)}개:")
    for i, s in enumerate(samples, 1):
        print(f"  {i:2}. {s}")


# ─────────────────────────────────────────
# 엔트리포인트
# ─────────────────────────────────────────
if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1 and sys.argv[1] == "test":
        # 테스트 모드: python generate_synthetic_dataset.py test [label_id]
        label_id = sys.argv[2] if len(sys.argv) > 2 else "N02-03"
        test_single_label(label_id)
    else:
        # 전체 생성 모드
        generate_dataset()

"""
합성 임베딩 학습 데이터 생성 스크립트 v2
개선사항:
  1. 스타일 강제 분리 (직접발화/간접보고/상황묘사/완곡표현)
  2. hard negative 데이터셋 별도 생성
  3. embedding 기반 post-filter (cosine similarity > 0.92 제거)
  4. confusion pair 기반 경계 데이터 생성

실행:
  python generate_synthetic_dataset_v2.py test M10-01     # 단일 라벨 테스트
  python generate_synthetic_dataset_v2.py test_hard N02-03 # hard negative 테스트
  python generate_synthetic_dataset_v2.py                  # 전체 생성
"""

import json, time, os, random, math
from pathlib import Path
from collections import defaultdict

# ─────────────────────────────────────────
# 설정
# ─────────────────────────────────────────
SAMPLES_PER_LABEL       = 100   # 라벨당 clean 샘플 수
HARD_NEG_PER_LABEL      = 30    # 라벨당 hard negative 수
CONFUSION_PER_PAIR      = 20    # confusion pair당 샘플 수
BATCH_SIZE              = 25
OUTPUT_CLEAN            = "synthetic_clean.json"
OUTPUT_HARD_NEG         = "synthetic_hard_negative.json"
OUTPUT_CONFUSION        = "synthetic_confusion.json"
CHECKPOINT_PATH         = "generate_checkpoint_v2.json"
MODEL                   = "claude-sonnet-4-20250514"
MAX_TOKENS              = 4096
RETRY_LIMIT             = 3
RETRY_DELAY             = 5
SIMILARITY_THRESHOLD    = 0.92   # cosine similarity 이상이면 중복으로 제거

# ─────────────────────────────────────────
# Confusion Pair 정의
# 같은 macro 내 혼동 가능한 쌍 + cross-macro 혼동 쌍
# ─────────────────────────────────────────
CONFUSION_PAIRS = [
    # 같은 macro — 가장 혼동하기 쉬운 쌍
    ("M19-01", "N19-01"),   # 신속한 의사결정 vs 독단 결정  ← 핵심
    ("M06-01", "N01-01"),   # 목표 명확화 vs 비현실적 목표
    ("M02-01", "N02-01"),   # 내재적 동기 자극 vs 공포 기반 동기
    ("M02-03", "N02-02"),   # 격려 및 인정 vs 보상 과장 약속
    ("N02-02", "N02-03"),   # 보상 과장 약속 vs 감정적 압박  ← T105 핵심
    ("M07-01", "N07-02"),   # 구체적 피드백 vs 공개적 질책
    ("M07-02", "N07-01"),   # 성장 지향 피드백 vs 성과만으로 평가
    ("M08-01", "N08-01"),   # 책임 준수 vs 책임 전가
    ("M08-02", "N08-02"),   # 공정한 성과 인정 vs 책임 회피 발언
    ("M10-01", "N10-01"),   # 실행력 및 완수 vs 계획만 반복
    ("M10-01", "N10-02"),   # 실행력 및 완수 vs 마감 미준수
    ("M11-01", "N11-01"),   # 적극적 경청 vs 대화 끊기
    ("M12-01", "N12-01"),   # 공감 및 배려 vs 감정 무시
    ("M15-01", "N15-03"),   # 심리적 안전감 vs 공개적 비난
    ("M15-06", "N15-04"),   # 심리적 보호 vs 실수 처벌
    ("M18-01", "N18-01"),   # 불확실성 속 안정감 vs 불안 조장
    ("M18-01", "N18-02"),   # 불확실성 속 안정감 vs 위기 과장
    ("M20-01", "N18-02"),   # 위기 대응 vs 위기 과장
    ("M23-01", "N23-01"),   # 혁신 기회 탐색 vs 혁신 아이디어 차단
    ("M28-01", "N28-01"),   # 투명한 소통 vs 정보 은폐
    ("M30-01", "N30-01"),   # 언행 일치 vs 말과 행동 불일치
    ("M33-01", "N33-01"),   # 도덕적 용기 vs 부당행위 묵인
    ("N02-01", "N02-03"),   # 공포 기반 동기 vs 감정적 압박
    ("N08-01", "N08-03"),   # 직접 책임 전가 vs 의사결정 지연
    ("N15-01", "N15-02"),   # 의견 무시 vs 발언 차단
    ("N15-03", "N15-05"),   # 공개적 비난 vs 불신 조장
]

# ─────────────────────────────────────────
# 프롬프트
# ─────────────────────────────────────────
SYSTEM_CLEAN = """당신은 한국어 리더십 텍스트 분석 시스템의 학습 데이터를 생성하는 전문가입니다.

규칙:
1. 실제 업무 현장에서 리더가 말하거나 행동하는 상황을 묘사합니다
2. ~, [내용], {내용} 같은 placeholder를 절대 사용하지 않습니다
3. 모든 문장은 완성된 구체적 표현이어야 합니다
4. not_when 조건에 해당하는 문장은 절대 생성하지 않습니다
5. 아래 4가지 스타일을 최대한 고르게 섞어서 생성합니다:
   A. 직접 발화: 리더가 직접 말하는 문장 ("~하겠습니다", "~해주세요")
   B. 간접 보고: 제3자 시점에서 묘사 ("팀장이 ~라고 말했다", "리더가 ~를 지시했다")
   C. 상황 묘사: 행동과 분위기 묘사 ("회의에서 ~분위기가 형성됐다", "팀 전체가 ~를 느꼈다")
   D. 완곡 표현: 부드럽거나 우회적 표현 ("~하는 것이 좋을 것 같습니다", "~를 검토해보면 어떨까요")
6. 문장 길이는 20~120자로 다양하게 작성합니다

응답 형식: JSON 배열만 반환합니다. 설명 없이 ["문장1", "문장2", ...] 형식만 반환합니다."""

SYSTEM_HARD_NEG = """당신은 한국어 NLP 모델의 경계(boundary) 학습 데이터를 생성하는 전문가입니다.

목표: 특정 라벨처럼 보이지만 실제로는 해당 라벨이 아닌 문장을 생성합니다.
이 데이터는 모델이 "비슷하지만 다른 것"을 구별하는 능력을 키우기 위해 사용됩니다.

규칙:
1. 표면적으로는 해당 라벨 같아 보이지만, 실제 의미나 의도가 다른 문장을 생성합니다
2. not_when 조건에 해당하는 상황이거나, 형식은 같지만 내용이 다른 문장입니다
3. ~, placeholder를 절대 사용하지 않습니다
4. 완성된 구체적 표현이어야 합니다

응답 형식: JSON 배열만 반환합니다. ["문장1", "문장2", ...] 형식만 반환합니다."""

SYSTEM_CONFUSION = """당신은 한국어 NLP 모델의 경계(boundary) 학습 데이터를 생성하는 전문가입니다.

목표: 두 라벨을 구별하는 능력을 키우기 위한 데이터를 생성합니다.
각 라벨에 해당하는 문장을 생성하되, 두 라벨의 핵심 차이가 명확히 드러나야 합니다.

규칙:
1. ~, placeholder를 절대 사용하지 않습니다
2. 완성된 구체적 표현이어야 합니다
3. 두 라벨의 경계선에 있는 미묘한 차이를 표현하는 문장을 포함합니다

응답 형식: 아래 JSON 형식만 반환합니다:
{
  "label_a": ["라벨A 문장1", "라벨A 문장2", ...],
  "label_b": ["라벨B 문장1", "라벨B 문장2", ...]
}"""

USER_CLEAN = """라벨: {label_id} ({label_name})
정의: {definition}
적용 상황: {when_keywords}
제외 상황: {not_when}

위 라벨에 해당하는 문장 {n}개를 4가지 스타일(직접발화/간접보고/상황묘사/완곡표현)을 골고루 섞어서 생성하세요."""

USER_HARD_NEG = """라벨: {label_id} ({label_name})
정의: {definition}
적용 상황: {when_keywords}
제외 상황: {not_when}

위 라벨처럼 보이지만 실제로는 해당 라벨이 아닌 문장 {n}개를 생성하세요.
(표면적으로 유사하지만 의미나 의도가 다른 문장 — 제외 상황에 해당하거나, 형식은 같지만 실제로는 다른 라벨인 경우)"""

USER_CONFUSION = """라벨 A: {label_a_id} ({label_a_name})
정의 A: {definition_a}
적용 상황 A: {when_a}

라벨 B: {label_b_id} ({label_b_name})
정의 B: {definition_b}
적용 상황 B: {when_b}

두 라벨의 차이가 명확히 드러나는 문장을 각각 {n}개씩 생성하세요.
특히 두 라벨의 경계선에 있는 미묘한 차이를 표현하는 문장을 포함하세요."""


# ─────────────────────────────────────────
# API 호출
# ─────────────────────────────────────────
def call_api(system_prompt: str, user_prompt: str) -> str:
    import urllib.request
    payload = json.dumps({
        "model": MODEL,
        "max_tokens": MAX_TOKENS,
        "system": system_prompt,
        "messages": [{"role": "user", "content": user_prompt}]
    }).encode("utf-8")

    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=payload,
        headers={"Content-Type": "application/json", "anthropic-version": "2023-06-01"},
        method="POST"
    )
    for attempt in range(RETRY_LIMIT):
        try:
            with urllib.request.urlopen(req, timeout=60) as resp:
                result = json.loads(resp.read())
                return result["content"][0]["text"].strip()
        except Exception as e:
            print(f"    API 오류 (시도 {attempt+1}/{RETRY_LIMIT}): {e}")
            if attempt < RETRY_LIMIT - 1:
                time.sleep(RETRY_DELAY * (attempt + 1))
    return ""


def parse_list(raw: str) -> list[str]:
    """API 응답에서 JSON 배열 파싱"""
    raw = raw.strip()
    if raw.startswith("```"):
        parts = raw.split("```")
        raw = parts[1] if len(parts) > 1 else raw
        if raw.startswith("json"):
            raw = raw[4:]
    raw = raw.strip()
    try:
        return json.loads(raw)
    except Exception:
        # 부분 파싱 시도
        try:
            start = raw.find("[")
            end = raw.rfind("]") + 1
            return json.loads(raw[start:end])
        except Exception:
            return []


def parse_dict(raw: str) -> dict:
    """API 응답에서 JSON 객체 파싱"""
    raw = raw.strip()
    if raw.startswith("```"):
        parts = raw.split("```")
        raw = parts[1] if len(parts) > 1 else raw
        if raw.startswith("json"):
            raw = raw[4:]
    raw = raw.strip()
    try:
        return json.loads(raw)
    except Exception:
        try:
            start = raw.find("{")
            end = raw.rfind("}") + 1
            return json.loads(raw[start:end])
        except Exception:
            return {}


# ─────────────────────────────────────────
# 품질 필터
# ─────────────────────────────────────────
BAD_PATTERNS = [
    "라고 반복적으로 강조했습니다",
    "이어서 팀원들의 반응을 보며 추가 지시를 내렸다",
    "부탁드립니다 라고",
    "그대로 진행되었습니다",
    "팀원들이 부담을 느꼈습니다",
    "라는 지시가 내려왔습니다",
]

def rule_filter(sentences: list[str]) -> list[str]:
    """규칙 기반 필터"""
    filtered = []
    for s in sentences:
        s = s.strip()
        if any(p in s for p in ["~", "[내용]", "{내용}"]):
            continue
        if len(s) < 15 or len(s) > 200:
            continue
        if any(bp in s for bp in BAD_PATTERNS):
            continue
        filtered.append(s)
    return filtered


def cosine_similarity(v1: list[float], v2: list[float]) -> float:
    dot = sum(a * b for a, b in zip(v1, v2))
    n1 = math.sqrt(sum(a * a for a in v1))
    n2 = math.sqrt(sum(b * b for b in v2))
    return dot / (n1 * n2) if n1 and n2 else 0.0


def embedding_filter(sentences: list[str], threshold: float = SIMILARITY_THRESHOLD) -> list[str]:
    """
    cosine similarity 기반 중복 제거
    sentence-transformers가 없으면 스킵 (rule filter만 적용)
    """
    try:
        from sentence_transformers import SentenceTransformer
        model = SentenceTransformer("nlpai-lab/KoE5")
        embeddings = model.encode(sentences, normalize_embeddings=True).tolist()

        kept = []
        kept_embs = []
        for i, (sent, emb) in enumerate(zip(sentences, embeddings)):
            too_similar = any(
                cosine_similarity(emb, kept_emb) > threshold
                for kept_emb in kept_embs
            )
            if not too_similar:
                kept.append(sent)
                kept_embs.append(emb)
        return kept
    except ImportError:
        # sentence_transformers 없으면 스킵
        return sentences


def dedup_filter(sentences: list[str], existing: set[str]) -> list[str]:
    """완전 중복 제거"""
    result = []
    for s in sentences:
        if s not in existing:
            result.append(s)
            existing.add(s)
    return result


# ─────────────────────────────────────────
# 라벨 로드
# ─────────────────────────────────────────
def load_labels() -> dict[str, dict]:
    with open("positive_micro_labels_enhanced.json") as f:
        pos = {l["label_id"]: l for l in json.load(f)["micro_labels"]}
    with open("negative_micro_labels_enhanced.json") as f:
        neg = {l["label_id"]: l for l in json.load(f)["micro_labels"]}
    return {**pos, **neg}


def get_when_keywords(label: dict) -> str:
    """when 필드에서 키워드 부분만 추출 (예시 제외)"""
    when = label.get("when", "")
    return when.split("|")[0].strip() if "|" in when else when


# ─────────────────────────────────────────
# 1단계: Clean 데이터 생성
# ─────────────────────────────────────────
def generate_clean(labels: dict, checkpoint: dict) -> list[dict]:
    done = set(checkpoint.get("clean_done", []))
    results = checkpoint.get("clean_results", [])

    total = len(labels)
    for i, (lid, label) in enumerate(labels.items()):
        if lid in done:
            print(f"[Clean {i+1}/{total}] {lid} - 스킵")
            continue

        print(f"[Clean {i+1}/{total}] {lid} ({label['label_name']}) ...", end="", flush=True)

        existing = set()
        samples = []
        attempts = 0

        while len(samples) < SAMPLES_PER_LABEL and attempts < 8:
            needed = SAMPLES_PER_LABEL - len(samples) + 5
            batch_n = min(BATCH_SIZE, needed)

            user = USER_CLEAN.format(
                label_id=lid,
                label_name=label["label_name"],
                definition=label.get("definition", label["label_name"]),
                when_keywords=get_when_keywords(label),
                not_when=label.get("not_when", "없음"),
                n=batch_n
            )
            raw = call_api(SYSTEM_CLEAN, user)
            batch = parse_list(raw)
            batch = rule_filter(batch)
            batch = dedup_filter(batch, existing)

            samples.extend([{
                "text": s,
                "label_id": lid,
                "label_name": label["label_name"],
                "label_type": "positive" if lid.startswith("M") else "negative",
                "data_type": "clean"
            } for s in batch])

            attempts += 1
            time.sleep(0.5)

        # embedding 기반 중복 제거 (100개 넘으면 적용)
        if len(samples) > SAMPLES_PER_LABEL:
            texts = [s["text"] for s in samples]
            texts_filtered = embedding_filter(texts)
            samples = [s for s in samples if s["text"] in set(texts_filtered)]
            if len(samples) > SAMPLES_PER_LABEL:
                samples = random.sample(samples, SAMPLES_PER_LABEL)

        results.extend(samples)
        done.add(lid)
        print(f" {len(samples)}개")

        if (i + 1) % 5 == 0:
            checkpoint["clean_done"] = list(done)
            checkpoint["clean_results"] = results
            save_checkpoint(checkpoint)

    checkpoint["clean_done"] = list(done)
    checkpoint["clean_results"] = results
    return results


# ─────────────────────────────────────────
# 2단계: Hard Negative 생성
# ─────────────────────────────────────────
def generate_hard_negatives(labels: dict, checkpoint: dict) -> list[dict]:
    done = set(checkpoint.get("hard_done", []))
    results = checkpoint.get("hard_results", [])

    total = len(labels)
    for i, (lid, label) in enumerate(labels.items()):
        if lid in done:
            print(f"[Hard {i+1}/{total}] {lid} - 스킵")
            continue

        print(f"[Hard {i+1}/{total}] {lid} ({label['label_name']}) ...", end="", flush=True)

        user = USER_HARD_NEG.format(
            label_id=lid,
            label_name=label["label_name"],
            definition=label.get("definition", label["label_name"]),
            when_keywords=get_when_keywords(label),
            not_when=label.get("not_when", "없음"),
            n=HARD_NEG_PER_LABEL
        )
        raw = call_api(SYSTEM_HARD_NEG, user)
        batch = parse_list(raw)
        batch = rule_filter(batch)

        samples = [{
            "text": s,
            "label_id": lid,
            "label_name": label["label_name"],
            "label_type": "positive" if lid.startswith("M") else "negative",
            "data_type": "hard_negative",
            "is_negative_of": lid   # 이 라벨의 hard negative임을 표시
        } for s in batch]

        results.extend(samples)
        done.add(lid)
        print(f" {len(samples)}개")

        time.sleep(0.5)
        if (i + 1) % 5 == 0:
            checkpoint["hard_done"] = list(done)
            checkpoint["hard_results"] = results
            save_checkpoint(checkpoint)

    checkpoint["hard_done"] = list(done)
    checkpoint["hard_results"] = results
    return results


# ─────────────────────────────────────────
# 3단계: Confusion Pair 생성
# ─────────────────────────────────────────
def generate_confusion(labels: dict, checkpoint: dict) -> list[dict]:
    done = set(checkpoint.get("confusion_done", []))
    results = checkpoint.get("confusion_results", [])

    total = len(CONFUSION_PAIRS)
    for i, (lid_a, lid_b) in enumerate(CONFUSION_PAIRS):
        pair_key = f"{lid_a}_{lid_b}"
        if pair_key in done:
            print(f"[Confusion {i+1}/{total}] {lid_a} vs {lid_b} - 스킵")
            continue

        la = labels.get(lid_a)
        lb = labels.get(lid_b)
        if not la or not lb:
            print(f"[Confusion {i+1}/{total}] {lid_a} vs {lid_b} - 라벨 없음 스킵")
            done.add(pair_key)
            continue

        print(f"[Confusion {i+1}/{total}] {lid_a} vs {lid_b} ...", end="", flush=True)

        user = USER_CONFUSION.format(
            label_a_id=lid_a, label_a_name=la["label_name"],
            definition_a=la.get("definition", la["label_name"]),
            when_a=get_when_keywords(la),
            label_b_id=lid_b, label_b_name=lb["label_name"],
            definition_b=lb.get("definition", lb["label_name"]),
            when_b=get_when_keywords(lb),
            n=CONFUSION_PER_PAIR // 2
        )
        raw = call_api(SYSTEM_CONFUSION, user)
        parsed = parse_dict(raw)

        cnt = 0
        for key, target_lid, target_label in [("label_a", lid_a, la), ("label_b", lid_b, lb)]:
            for s in rule_filter(parsed.get(key, [])):
                results.append({
                    "text": s,
                    "label_id": target_lid,
                    "label_name": target_label["label_name"],
                    "label_type": "positive" if target_lid.startswith("M") else "negative",
                    "data_type": "confusion",
                    "confusion_pair": pair_key
                })
                cnt += 1

        done.add(pair_key)
        print(f" {cnt}개")

        time.sleep(0.5)
        if (i + 1) % 5 == 0:
            checkpoint["confusion_done"] = list(done)
            checkpoint["confusion_results"] = results
            save_checkpoint(checkpoint)

    checkpoint["confusion_done"] = list(done)
    checkpoint["confusion_results"] = results
    return results


# ─────────────────────────────────────────
# 체크포인트
# ─────────────────────────────────────────
def load_checkpoint() -> dict:
    if Path(CHECKPOINT_PATH).exists():
        with open(CHECKPOINT_PATH) as f:
            return json.load(f)
    return {}


def save_checkpoint(cp: dict):
    with open(CHECKPOINT_PATH, "w", encoding="utf-8") as f:
        json.dump(cp, f, ensure_ascii=False)


# ─────────────────────────────────────────
# 통계 출력
# ─────────────────────────────────────────
def print_stats(data: list[dict], title: str):
    from collections import Counter
    print(f"\n{'='*50}")
    print(f"{title}")
    print(f"총 {len(data)}개")
    by_type = Counter(d["data_type"] for d in data)
    for dt, cnt in by_type.items():
        print(f"  {dt}: {cnt}개")
    by_label = Counter(d["label_id"] for d in data)
    print(f"라벨 수: {len(by_label)}개")
    print(f"라벨당 최소/최대: {min(by_label.values())} / {max(by_label.values())}개")
    under = [lid for lid, cnt in by_label.items() if cnt < 80]
    if under:
        print(f"80개 미만 라벨: {under}")


# ─────────────────────────────────────────
# 테스트 모드
# ─────────────────────────────────────────
def test_single(label_id: str):
    labels = load_labels()
    label = labels.get(label_id)
    if not label:
        print(f"라벨 {label_id} 없음")
        return

    print(f"\n[Clean 테스트] {label_id} ({label['label_name']})")
    user = USER_CLEAN.format(
        label_id=label_id, label_name=label["label_name"],
        definition=label.get("definition", ""), when_keywords=get_when_keywords(label),
        not_when=label.get("not_when", "없음"), n=10
    )
    raw = call_api(SYSTEM_CLEAN, user)
    samples = rule_filter(parse_list(raw))
    print(f"생성 {len(samples)}개:")
    for i, s in enumerate(samples, 1):
        print(f"  {i:2}. [{len(s)}자] {s}")


def test_hard(label_id: str):
    labels = load_labels()
    label = labels.get(label_id)
    if not label:
        print(f"라벨 {label_id} 없음")
        return

    print(f"\n[Hard Negative 테스트] {label_id} ({label['label_name']})")
    user = USER_HARD_NEG.format(
        label_id=label_id, label_name=label["label_name"],
        definition=label.get("definition", ""), when_keywords=get_when_keywords(label),
        not_when=label.get("not_when", "없음"), n=10
    )
    raw = call_api(SYSTEM_HARD_NEG, user)
    samples = rule_filter(parse_list(raw))
    print(f"생성 {len(samples)}개:")
    for i, s in enumerate(samples, 1):
        print(f"  {i:2}. [{len(s)}자] {s}")


def test_confusion(lid_a: str, lid_b: str):
    labels = load_labels()
    la, lb = labels.get(lid_a), labels.get(lid_b)
    if not la or not lb:
        print("라벨 없음")
        return

    print(f"\n[Confusion 테스트] {lid_a} vs {lid_b}")
    user = USER_CONFUSION.format(
        label_a_id=lid_a, label_a_name=la["label_name"],
        definition_a=la.get("definition", ""), when_a=get_when_keywords(la),
        label_b_id=lid_b, label_b_name=lb["label_name"],
        definition_b=lb.get("definition", ""), when_b=get_when_keywords(lb),
        n=5
    )
    raw = call_api(SYSTEM_CONFUSION, user)
    parsed = parse_dict(raw)
    for key, lid in [("label_a", lid_a), ("label_b", lid_b)]:
        print(f"\n  [{lid}]:")
        for s in rule_filter(parsed.get(key, [])):
            print(f"    [{len(s)}자] {s}")


# ─────────────────────────────────────────
# 메인
# ─────────────────────────────────────────
def main():
    labels = load_labels()
    print(f"라벨 수: {len(labels)}개")

    checkpoint = load_checkpoint()
    done_stages = checkpoint.get("done_stages", [])

    # 1단계: Clean
    if "clean" not in done_stages:
        print("\n" + "="*50)
        print("1단계: Clean 데이터 생성")
        clean_results = generate_clean(labels, checkpoint)
        random.shuffle(clean_results)
        with open(OUTPUT_CLEAN, "w", encoding="utf-8") as f:
            json.dump(clean_results, f, ensure_ascii=False, indent=2)
        print_stats(clean_results, "Clean 완료")
        checkpoint["done_stages"] = done_stages + ["clean"]
        save_checkpoint(checkpoint)
    else:
        print("1단계 Clean - 이미 완료, 스킵")

    # 2단계: Hard Negative
    if "hard" not in done_stages:
        print("\n" + "="*50)
        print("2단계: Hard Negative 생성")
        hard_results = generate_hard_negatives(labels, checkpoint)
        with open(OUTPUT_HARD_NEG, "w", encoding="utf-8") as f:
            json.dump(hard_results, f, ensure_ascii=False, indent=2)
        print_stats(hard_results, "Hard Negative 완료")
        checkpoint["done_stages"] = checkpoint.get("done_stages", []) + ["hard"]
        save_checkpoint(checkpoint)
    else:
        print("2단계 Hard Negative - 이미 완료, 스킵")

    # 3단계: Confusion Pair
    if "confusion" not in done_stages:
        print("\n" + "="*50)
        print("3단계: Confusion Pair 생성")
        confusion_results = generate_confusion(labels, checkpoint)
        with open(OUTPUT_CONFUSION, "w", encoding="utf-8") as f:
            json.dump(confusion_results, f, ensure_ascii=False, indent=2)
        print_stats(confusion_results, "Confusion Pair 완료")
        checkpoint["done_stages"] = checkpoint.get("done_stages", []) + ["confusion"]
        save_checkpoint(checkpoint)
    else:
        print("3단계 Confusion Pair - 이미 완료, 스킵")

    # 체크포인트 삭제
    if Path(CHECKPOINT_PATH).exists():
        os.remove(CHECKPOINT_PATH)

    print("\n모든 생성 완료!")
    print(f"  {OUTPUT_CLEAN}")
    print(f"  {OUTPUT_HARD_NEG}")
    print(f"  {OUTPUT_CONFUSION}")


if __name__ == "__main__":
    import sys
    args = sys.argv[1:]

    if not args:
        main()
    elif args[0] == "test" and len(args) >= 2:
        test_single(args[1])
    elif args[0] == "test_hard" and len(args) >= 2:
        test_hard(args[1])
    elif args[0] == "test_confusion" and len(args) >= 3:
        test_confusion(args[1], args[2])
    else:
        print("사용법:")
        print("  python generate_synthetic_dataset_v2.py                        # 전체 생성")
        print("  python generate_synthetic_dataset_v2.py test M10-01            # clean 테스트")
        print("  python generate_synthetic_dataset_v2.py test_hard N02-03       # hard negative 테스트")
        print("  python generate_synthetic_dataset_v2.py test_confusion M19-01 N19-01  # confusion 테스트")
